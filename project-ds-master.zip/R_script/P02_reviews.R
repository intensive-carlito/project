reviews=fread("C:/temp/projet/reviews.csv",stringsAsFactors=FALSE, encoding = 'UTF-8')

reviews2=reviews[listing_id==36490]